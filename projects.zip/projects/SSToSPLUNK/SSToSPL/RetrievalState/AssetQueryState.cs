﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace RetrievalState
{
    public class LastRetrievalTime
    {
        public string asset { get; set; }
        public DateTime lastQueryTime { get; set; }
    }

    public class AssetQueryState
    {
        private char delim = '|';
        private string filepath;

        //use with retrieveAdvisoriesPerAsset
        private string filenameAssets = "LastRetrievalTimes.txt";
        private List<LastRetrievalTime> _LastRetrievalTimes;
        public List<LastRetrievalTime> LastRetrievalTimes
        {
            get { return _LastRetrievalTimes; }
            set { _LastRetrievalTimes = value; }
        }

        //use with retrieveLastUpdatedAdvisories
        private string filename = "LastQueryTime.txt";
        private DateTime _lastQueryTime;
        public DateTime lastQueryTime
        {
            get { return _lastQueryTime; }
            set { _lastQueryTime = value; }
        }

        public AssetQueryState(string filepath)
        {
            this.filepath = filepath;
            _LastRetrievalTimes = new List<LastRetrievalTime>();
        }

        /// <summary>
        /// use with retrieveAdvisoriesPerAsset
        /// </summary>
        public void PersistQueryStates()
        {
            using(StreamWriter sw = new StreamWriter(Path.Combine(filepath,filenameAssets),false))
            {
                foreach(LastRetrievalTime lastq in _LastRetrievalTimes)
                {
                    sw.WriteLine(lastq.asset + delim.ToString() + lastq.lastQueryTime.ToString());
                }
            }
        }

        /// <summary>
        /// use with retrieveAdvisoriesPerAsset
        /// </summary>
        public void ReadQueryStates()
        {
            if (File.Exists(Path.Combine(filepath, filenameAssets)))
            {
                using(StreamReader sr = new StreamReader(Path.Combine(filepath,filenameAssets)))
                {
                    while (sr.Peek() > -1) 
                    {
                        string[] ln = sr.ReadLine().Split(delim);
                        LastRetrievalTime lastq = new LastRetrievalTime() { asset = ln[0], lastQueryTime = Convert.ToDateTime(ln[1]) };
                        _LastRetrievalTimes.Add(lastq);
                    }
                }
            }
        }

        /// <summary>
        /// use with retrieveLastUpdatedAdvisories
        /// </summary>
        public void ReadLastQueryTime()
        {
            if (File.Exists(Path.Combine(filepath, filename)))
            {
                using (StreamReader sr = new StreamReader(Path.Combine(filepath, filename)))
                {
                    while (sr.Peek() > -1)
                    {
                        _lastQueryTime = Convert.ToDateTime(sr.ReadLine());
                    }
                }
            }
        }

        /// <summary>
        /// use with retrieveLastUpdatedAdvisories
        /// </summary>
        public void PersistLastQueryTime()
        {
            using (StreamWriter sw = new StreamWriter(Path.Combine(filepath, filename), false))
            {
                sw.WriteLine(_lastQueryTime.ToString());
            }
        }

        /// <summary>
        /// use with retrieveAdvisoriesPerAsset
        /// </summary>
        /// <param name="asset"></param>
        /// <param name="currentTime"></param>
        /// <returns></returns>
        public DateTime retrieveQueryTime(string asset,DateTime currentTime)
        {
            DateTime ts = currentTime;
            LastRetrievalTime lastq = _LastRetrievalTimes.Where(x => String.Equals(x.asset, asset, StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();
            if (lastq != null)
            {
                ts = lastq.lastQueryTime;
            }
            return ts;
        }

        /// <summary>
        /// use with retrieveAdvisoriesPerAsset
        /// </summary>
        /// <param name="asset"></param>
        /// <param name="currentTime"></param>
        public void writeQueryTime(string asset, DateTime currentTime)
        {
            LastRetrievalTime lastq = _LastRetrievalTimes.Where(x => String.Equals(x.asset, asset, StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();
            if (lastq != null)
            {
                lastq.lastQueryTime = currentTime;
            }
            else
            {
                _LastRetrievalTimes.Add(new LastRetrievalTime() { asset = asset, lastQueryTime = currentTime });
            }
        }

        /// <summary>
        /// use with retrieveLastUpdatedAdvisories
        /// </summary>
        /// <param name="currentTime"></param>
        /// <returns></returns>
        public DateTime retrieveQueryTime(DateTime currentTime)
        {
            DateTime ts = currentTime;
            if (_lastQueryTime != null && !_lastQueryTime.Equals(DateTime.MinValue))
            {
                ts = _lastQueryTime;
            }
            return ts;
        }

    }
}
