﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SmartSignal.Com.EPICenter.Service.Contract;

namespace AdvisoriesQueries
{
    public class Queries
    {
        private string _classname = "Queries: ";
        private log4net.ILog _logger;
        public Queries(log4net.ILog logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// use with retrieveAdvisoriesPerAsset
        /// </summary>
        /// <param name="from"></param>
        /// <param name="To"></param>
        /// <param name="Asset"></param>
        /// <returns></returns>
        public List<returnedSet> GetAdvisories(DateTime from, DateTime To, string Asset)
        {
           // _logger.Debug(_classname + "in GetAdv");
            return new List<returnedSet>(){
             new returnedSet{
                Asset = Asset,
                AssetTagDataSourceName = "AmbTemperatur",
                AssetTagUnit = "degC",
                FirstOccurred = DateTime.Now.AddHours(-5),
                LastOccurred = DateTime.Now,
                Id = Guid.NewGuid(),
                LastStateChange = DateTime.Now.AddHours(-1),
                Message = "Temperature rose over the last 2 hours",
                Model = "temperature_Watch",
                ObservationCount = 4,
                OccurrenceCount = 3,
                Status = IncidentStatus.Investigating,
                TagName = "modelAmbTemperature"},
            new returnedSet{
                Asset = Asset,
                AssetTagDataSourceName = "TemperatureOilEngine",
                AssetTagUnit = "degC",
                FirstOccurred = DateTime.Now.AddHours(-4),
                LastOccurred = DateTime.Now,
                Id = Guid.NewGuid(),
                LastStateChange = DateTime.Now.AddHours(-2),
                Message = "Temperature oscillates over the last 2 hours",
                Model = "OilTemperature_Watch",
                //ObservationCount = 6,
                OccurrenceCount = 4,
                //TagName = "modelOilTemperature",
                Status = IncidentStatus.Investigating
               }
            };
        }

        /// <summary>
        /// use with retrieveLastUpdatedAdvisories
        /// </summary>
        /// <param name="updatedSince"></param>
        /// <returns></returns>
        public List<returnedSet> GetAdvisories(DateTime updatedSince)
        {
            // _logger.Debug(_classname + "in GetAdv");
            return new List<returnedSet>(){
             new returnedSet{
                Asset = "660035",
                AssetTagDataSourceName = "AmbTemperatur",
                AssetTagUnit = "degC",
                FirstOccurred = DateTime.Now.AddHours(-5),
                LastOccurred = DateTime.Now,
                Id = Guid.NewGuid(),
                LastStateChange = DateTime.Now.AddHours(-1),
                Message = "Temperature rose over the last 2 hours",
                Model = "temperature_Watch",
                ObservationCount = 4,
                OccurrenceCount = 3,
                Status = IncidentStatus.Investigating,
                TagName = "modelAmbTemperature"},
            new returnedSet{
                Asset = "660035",
                AssetTagDataSourceName = "TemperatureOilEngine",
                AssetTagUnit = "degC",
                FirstOccurred = DateTime.Now.AddHours(-4),
                LastOccurred = DateTime.Now,
                Id = Guid.NewGuid(),
                LastStateChange = DateTime.Now.AddHours(-2),
                Message = "Temperature oscillates over the last 2 hours",
                Model = "OilTemperature_Watch",
                //ObservationCount = 6,
                OccurrenceCount = 4,
                //TagName = "modelOilTemperature",
                Status = IncidentStatus.Investigating
               },
            new returnedSet{
                Asset = "660075",
                AssetTagDataSourceName = "TemperatureOilEngine",
                AssetTagUnit = "degC",
                FirstOccurred = DateTime.Now.AddHours(-4),
                LastOccurred = DateTime.Now,
                Id = Guid.NewGuid(),
                LastStateChange = DateTime.Now.AddHours(-2),
                Message = "Temperature oscillates over the last 2 hours",
                Model = "OilTemperature_Watch",
                //ObservationCount = 6,
                OccurrenceCount = 4,
                //TagName = "modelOilTemperature",
                Status = IncidentStatus.Investigating
               },
            new returnedSet{
                Asset = "670035",
                AssetTagDataSourceName = "TemperatureOilEngine",
                AssetTagUnit = "degC",
                FirstOccurred = DateTime.Now.AddHours(-4),
                LastOccurred = DateTime.Now,
                Id = Guid.NewGuid(),
                LastStateChange = DateTime.Now.AddHours(-2),
                Message = "Temperature oscillates over the last 2 hours",
                Model = "OilTemperature_Watch",
                //ObservationCount = 6,
                OccurrenceCount = 4,
                //TagName = "modelOilTemperature",
                Status = IncidentStatus.Investigating
               }
            };
        }

        public List<string> GetAssets()
        {
            List<string> assets = new List<string>();
            assets.Add("660035");
            assets.Add("660075");
            assets.Add("670035");
            assets.Add("670075");
            return assets;
        }
    }
}
