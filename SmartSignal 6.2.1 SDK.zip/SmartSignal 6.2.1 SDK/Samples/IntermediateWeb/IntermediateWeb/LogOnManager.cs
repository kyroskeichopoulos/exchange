﻿// Copyright 2010 SmartSignal Corporation
// For customer and partner use with SmartSignal products
// http://www.smartsignal.com/

using System;
using System.Web;
using System.Web.SessionState;
using SmartSignal.Com.EPICenter.Service.Web;

namespace IntermediateWeb
{
	internal static class LogOnManager
	{
		// Change as needed for your specific server and account.
		// You may choose to have the user or web page provide some of this information,
		// in which case they would no longer be constants.

		internal const string ServerAddress = "localhost";
		internal const string ServerPort = "80";
		private const string UserName = "JaneDoe";
		private const string Password = "password";

		// For sample code purposes, it is just easier to put all of the server specific info in this class.
        internal static readonly Guid ExampleChart = new Guid("31797DBF-1F80-4B38-A961-53BA6CDCA22A");

		internal static WebServiceConnection LogOnAsNeeded(HttpSessionState aspSession, HttpRequest pageRequest)
		{
			var webServiceConnection = new WebServiceConnection(aspSession, UserName, Password, ServerAddress, ServerPort,
																Resources.ApplicationName, pageRequest);

			return webServiceConnection;
		}
	}
}