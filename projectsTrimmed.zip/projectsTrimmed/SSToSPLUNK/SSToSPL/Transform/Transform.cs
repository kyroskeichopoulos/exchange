﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using AdvisoriesQueries;
using System.IO;
using System.IO.Compression;
using CsvHelper;
using DBServices;

namespace AdvisoriesTransformer
{
    public class Transform
    {
        private string _classname = "Transform: ";
        private log4net.ILog _logger;
        public Transform(log4net.ILog logger, string filepath, string filetype, string AVDBconnectionString)
        {
            _logger = logger;
            _filetype = filetype;
            _filepath = filepath;
            _avconStr = AVDBconnectionString;
            if(_avDB == null)
            {
                _avDB = new AssetData(_logger, _avconStr);
            }
        }

        private AssetData _avDB;
        private string _filepath;
        private string _filetype;
        private string _avconStr;

        public string AVDBconnectionString
        {
            get { return _avconStr; }
            set { _avconStr = value; }
        }
        public string filepath
        {
            get { return _filepath; }
            set { _filepath = value; }
        }
        public string filetype
        {
            get { return _filetype; }
            set { _filetype = value; }
        }

        public string ToFile(List<returnedSet> assetadvisories,string ftype)
        {
            if (assetadvisories.Count() == 0)
            {
                _logger.Info(_classname + "No advisories returned");
                return "";
            }
            try
            {
                //determine file name and path
                //find Baureihe
                string LokNr = assetadvisories.Select(x => x.Asset).FirstOrDefault();
                string BR = _avDB.GetBR(LokNr);
                //construct file name
                string filename = BR + "_" + LokNr + "_" + _filetype + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + "." + ftype;
                string filenamePath = Path.Combine(_filepath, filename);

                if(ftype.Equals("json",StringComparison.InvariantCultureIgnoreCase))
                {
                    ToJson(assetadvisories, filenamePath);
                }
                if (ftype.Equals("csv", StringComparison.InvariantCultureIgnoreCase))
                {
                    ToCsv(assetadvisories, filenamePath);
                }
                // zip
                //GZip_File(filenamePath);
                Zip_File(filenamePath, filename);
                return "";
            }
            catch (Exception e)
            {
                _logger.Error(_classname, e);
                return e.Message;
            }
        }

        private void ToJson(List<returnedSet> assetadvisories, string filenamePath)
        {
            // serialize
            JsonSerializer _serializer = new JsonSerializer();
            _serializer.DateTimeZoneHandling = DateTimeZoneHandling.Unspecified;
            using (StreamWriter sw = new StreamWriter(filenamePath))
            using (JsonWriter writer = new JsonTextWriter(sw))
            {
                _serializer.Serialize(writer, assetadvisories);
            }
        }

        private void ToCsv(List<returnedSet> assetadvisories, string filenamePath)
        {
            // write to file with header
            using (StreamWriter sw = new StreamWriter(filenamePath))
            using (CsvWriter writer = new CsvWriter(sw))
            {
                writer.WriteHeader<returnedSet>();
                writer.WriteRecords(assetadvisories);
            }
        }

        private void GZip_File(string path)
        {
            string zipext = ".gz";
            string zFilename = path + zipext;
            using (FileStream unzFile = File.OpenRead(path))
            {
                using (FileStream zFile = File.Create(zFilename))
                {
                    using(GZipStream compress = new GZipStream(zFile, CompressionMode.Compress))
                    {
                        unzFile.CopyTo(compress);
                    }
                }
            }
            // delete unzipped file
            File.Delete(path);
        }

        private void Zip_File(string path,string filename)
        {
            string zipext = ".zip";
            int extPos = path.LastIndexOf(".");
            string archName = path.Substring(0, extPos) + zipext;

            using (ZipArchive archive = ZipFile.Open(archName,ZipArchiveMode.Create))
            {
                ZipArchiveEntry fileEntry = archive.CreateEntryFromFile(path, filename);
            }
            // delete unzipped file
            File.Delete(path);
        }
    }
}
