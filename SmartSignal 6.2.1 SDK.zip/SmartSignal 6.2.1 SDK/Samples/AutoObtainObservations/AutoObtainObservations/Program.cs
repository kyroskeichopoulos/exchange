﻿// Copyright 2010 SmartSignal Corporation
// For customer and partner use with SmartSignal products
// http://www.smartsignal.com/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using SmartSignal.Com.Common;
using SmartSignal.Com.EPICenter.Service.Common;
using SmartSignal.Com.EPICenter.Service.Contract;

namespace AutoObtainObservations
{
    class Program
    {
        private const string userName = "admin";
        private const string password = "Password1";
        private const string serverUri = "localhost";
        private const string serverPort = "";
        private const string fileName = "Example Item Ids.txt";

        // ReSharper disable UnusedParameter.Local
        static void Main(string[] args)
        // ReSharper restore UnusedParameter.Local
        {
            try
            {
                if (args.Length > 0 && args[0].Equals("i", StringComparison.InvariantCultureIgnoreCase))
                    GetItems();
                else
                    GetObservations();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unexpected exception in Main: {0}", ex);
            }

#if DEBUG
            Console.WriteLine();
            Console.WriteLine("Press a key to exit.");
            Console.ReadKey(); // Wait for user keypress to exit.
#endif
            ServiceConnection.CloseAllServices(); // Just to be safe. This cleans up any connections that are still open due to a defect in the code.
        }

        private static void GetItems()
        {
            IItemService service = null;
            try
            {
                SessionInformation session = ServiceConnection.LogOnSimple(userName, password, serverUri, serverPort);

                service = session.Token.Create<IItemService>();

                List<Asset> assets = service.GetAssets(session.Token, null, false);
                List<Guid> ids = new List<Guid>();

                foreach (Asset asset in assets.Where(a => !a.IsCheckedOut))
                {
                    List<Guid> assetId = new List<Guid>{asset.Id};
                    List<AssetTag> tags = service.GetAssetTagsForAssets(session.Token, assetId, false);
                    List<ModelTag> modelTags = service.GetModelTagsForAssets(session.Token, assetId, false);
                    ids.AddRange(tags.Select(t=> t.Id));
                    ids.AddRange(modelTags.Select(t => t.Id));
                }

                using (FileStream fs = File.OpenWrite(fileName))
                {
                    byte[] serializedData = CompressionHelper.Serialize(ids.Distinct(), true);

                    fs.Write(serializedData,0,serializedData.Length);
                }
            }
            finally { if (service != null) service.Close(); }
        }

        /// <summary>
        /// This sample program:
        /// 1. Reads a file full of item ids
        /// 2. Logs onto a server without showing a user dialog.
        /// 3. Reads all the observations for each item id for the prior month.
        /// This program is overly cautious. It checks for exceptions and reports them. It can recover from broken connections.
        /// That makes it a great example for a reliable standalone automatic program.
        /// However, if you want simple, you can reduce the complexity in exchange for reduced robustness.
        /// </summary>
        private static void GetObservations()
        {
            SessionInformation session = null;
            try
            {
                // Put a list of item ids that you want to read the observations for into this file.
                // All non-guid text in the file will be ignored. So, you can add tag names and comments if you want.

                string fileContents = null;

                IEnumerable<Guid> ids = CompressionHelper.Deserialize<IEnumerable<Guid>>(File.OpenRead(fileName),true);
                if(ids == null || !ids.Any())
                {
                    Console.WriteLine("Unable to get item ids from file named {0}.", fileName);
                    return;
                }

                //logon
                session = ServiceConnection.LogOnSimple(userName, password, serverUri, serverPort);
                if (!session.IsValidSession())
                {
                    string detail = session != null && session.LogOnResult != null &&
                                    !String.IsNullOrEmpty(session.LogOnResult.Reason)
                                        ? String.Format(" due to: {0}", session.LogOnResult.Reason)
                                        : String.Empty;
                    Console.WriteLine("Unable to logon to {0}{1}", serverUri, detail);
                    return;
                }
                Console.WriteLine("Successful logon to {0} at {1}!", session.Installation.DisplayName, serverUri);

                // Get the date range for the previous month.
                //var startDate = DateTime.Now;
                var endDate = DateTime.Now;
                var startDate = endDate.AddMonths(-1);

                const int millisecondsBetweenReads = 1000; // One second

                ObtainAllObservations(session, ids, startDate, endDate, millisecondsBetweenReads);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            finally
            {
                // No matter what happens (exceptions, whatever), we need to log off.
                if (session != null)
                    session.LogOffSimple();
            }
        }

        private static void ObtainAllObservations(SessionInformation session, IEnumerable<Guid> itemIds, DateTime startDate, DateTime endDate, int millisecondsBetweenReads)
        {
            // Make sure the caller passed a valid logon and list of item ids.
            if (session.IsValidSession() && itemIds != null && itemIds.Any())
            {
                // Never trust the caller. Limit it if they pass a really large time to wait between reads.
                const int maximumMillisecondsBetweenReads = 5 * 60 * 1000; // No more than five minutes between reads. Make this whatever you want for the limit.

                if (millisecondsBetweenReads > maximumMillisecondsBetweenReads)
                {
                    millisecondsBetweenReads = maximumMillisecondsBetweenReads;
                }

                IChartService chartService = null; // We don't have a connection yet.
                var firstItem = true;

                try
                {
                    foreach (var itemId in itemIds) // Go through the entire list of ids provided.
                    {
                        if (itemId != Guid.Empty) // Only process non-empty guids.
                        {
                            var success = false;
                            const int maximumNumberOfAttempts = 2; // Will try to obtain the data at least this many times. Increase for unreliable networks.
                            var currentNumberOfAttempts = maximumNumberOfAttempts;

                            do
                            {
                                if (firstItem)
                                {
                                    // Don't sleep the first time through the loop.
                                    firstItem = false;
                                }
                                else if (millisecondsBetweenReads > 0)
                                {
                                    // This allows you to pause between reads to avoid overwhelming the server and to give CPU time to the local machine.
                                    Thread.Sleep(millisecondsBetweenReads);
                                }

                                // This creates a connection to the chart service, reusing the existing connection if it exists and is not broken.
                                chartService = session.Token.Create<IChartService>();

                                if (ServiceConnection.IsGood(chartService) == false)
                                {
                                    Console.WriteLine("Unable to create a service connection.");
                                }
                                else
                                {
                                    try
                                    {
                                        var observations = chartService.GetObservations(session.Token, itemId, startDate, endDate);

                                        // ReSharper disable ConvertIfStatementToNullCoalescingExpression
                                        if (observations == null) // To avoid extra code to handle null, make an empty list.
                                        {
                                            observations = new List<Observation>();
                                        }
                                        // ReSharper restore ConvertIfStatementToNullCoalescingExpression

                                        success = true;

                                        ProcessObservations(session, itemId, startDate, endDate, observations);
                                    }
                                    catch (Exception ex)
                                    {
                                        Console.WriteLine("When attempting to obtain or process observations for {0}, encountered an exception of: {1}", itemId,
                                                          ex.Message);
                                    }
                                }

                            } while (success == false && currentNumberOfAttempts-- > 0);

                            if (success == false)
                            {
                                Console.WriteLine("Aborting after {0} attempts.", maximumNumberOfAttempts);
                                break; // Abort trying to get any more items.
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Unexpected exception in ObtainAllObservations: {0}", ex);
                }
                finally
                {
                    // No matter what happens (exceptions, whatever), we need to close our service connection.
                    chartService.Close();
                }
            }
        }

        // ReSharper disable UnusedParameter.Local
        private static void ProcessObservations(SessionInformation session, Guid itemId, DateTime startDate, DateTime endDate, List<Observation> observations)
        // ReSharper restore UnusedParameter.Local
        {
            // I included a bunch of parameters in case you need them.

            if (observations != null)
            {
                Console.WriteLine("Obtained {0} observations for {1}.", observations.Count, itemId);

                foreach (var observation in observations)
                {
                    if (observation != null)
                    {
                        Console.Write("Observation id {0} on {1} actual value is: ", observation.ObservationLegacyId, observation.ObservationDate);

                        if (observation.IsActualNull)
                        {
                            Console.WriteLine("null");
                        }
                        else
                        {
                            Console.WriteLine(observation.Actual);
                        }

                        // We don't really want to loop through all the observations and write them to the console.
                        // But, I wanted to include code to show you how to loop through all the values.
                        break; // Remove this line to process all of the observations.
                    }
                }
            }
        }
    }
}
