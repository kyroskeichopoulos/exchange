package com.ge.dspmicro.sql.adapter;

import java.sql.*;
import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.dspmicro.machinegateway.types.PDataValue;
import com.ge.dspmicro.machinegateway.types.PEnvelope;
import com.ge.dspmicro.machinegateway.types.PQuality;
import com.ge.dspmicro.machinegateway.types.PQuality.QualityEnum;
import com.ge.dspmicro.machinegateway.types.PTimestamp;

import java.text.*;

//import com.microsoft.sqlserver.jdbc.*;

public class SQLConnector
{
	private String connectionString;
	Connection con = null;
	CallableStatement cstmt = null;
	ResultSet rs = null;
	
	public SQLConnector(String connString)
	{
		connectionString = connString;
	}
	
	public List<String> getTags(String LocoRange)
	{
		List<String> lst = new ArrayList<String>();
	  try 
	  {
		  // Establish the connection.
		  Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		  con = DriverManager.getConnection(connectionString);
		  // Create and execute an SQL statement
		  
		  String SQL = "{call dbo.spLocal_GetTags(?)}";
		  cstmt = con.prepareCall(SQL);
		  cstmt.setString(1, LocoRange);
		  rs = cstmt.executeQuery();
		  AddToList(lst, rs);
	  }
	  catch (Exception e) 
	  {
		  e.printStackTrace();	
	  }
	  finally 
	  {
		  if (rs != null) try { rs.close(); } catch(Exception e) {}
		  if (cstmt != null) try { cstmt.close(); } catch(Exception e) {}
		  if (con != null) try { con.close(); } catch(Exception e) {}
	  }
	  return lst;
	}

	public List<PDataValue> getTagValues(Map<String, SampleDataNode> tags,String LocoRange)
	{
		List<PDataValue> lst = new ArrayList<PDataValue>();
		try 
		{
			// Establish the connection.
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(connectionString);
			
			String SQL = "{call dbo.spLocal_GetTagValues(?)}";
			cstmt = con.prepareCall(SQL);
			cstmt.setString(1, LocoRange);
			rs = cstmt.executeQuery();
			AddToValues(lst, rs, tags);
		}
		catch (Exception e) 
		{
			e.printStackTrace();	
		}
		finally 
		{
			if (rs != null) try { rs.close(); } catch(Exception e) {}
			if (cstmt != null) try { cstmt.close(); } catch(Exception e) {}
			if (con != null) try { con.close(); } catch(Exception e) {}
		}
		return lst;
	}
	
	private static void AddToList(List<String> lst, ResultSet rs)
	{
	    try 
	    {
	       while (rs.next()) 
	       {
	    	   lst.add(rs.getString(1));
	       }
	    } 
	    catch (Exception e) 
	    {
	       e.printStackTrace();
	    }
	}
	
	private static void AddToValues(List<PDataValue> lst, ResultSet rs,Map<String, SampleDataNode> tags)
	{
	    try 
	    {
	       while (rs.next()) 
	       {
	    	   SampleDataNode node = tags.get(rs.getString(1));
	    	   if(node != null)
	    	   {
					PEnvelope envelope = new PEnvelope(rs.getString(2));
					PDataValue value = new PDataValue(node.getNodeId(), envelope);
					value.setNodeName(node.getName());
					value.setAddress(node.getAddress());
					
					PTimestamp ts = new PTimestamp(1000*Long.parseLong(rs.getString(3)));
					value.setTimestamp(ts);
					
					QualityEnum qty = null;
					qty = QualityEnum.GOOD;
					if(!rs.getString(4).equalsIgnoreCase("Good"))
					{
						qty = QualityEnum.BAD;
					}
					PQuality dq = new PQuality(qty);
					value.setQuality(dq);
					
					lst.add(value);
	    	   }
	       }
	    } 
	    catch (Exception e) 
	    {
	       e.printStackTrace();
	    }
	}	
}
