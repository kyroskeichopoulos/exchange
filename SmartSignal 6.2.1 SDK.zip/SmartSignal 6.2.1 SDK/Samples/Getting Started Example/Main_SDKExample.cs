﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//Step 1 - SmartSignal references
using SmartSignal.Com.EPICenter.Service.Client;
using SmartSignal.Com.EPICenter.Service.Common;
using SmartSignal.Com.EPICenter.Service.Contract;

namespace SmartSignal_SDK_Example
{
    class Main_SDKExample
    {
        [STAThread]
        public static void Main(string[] argv)
        {
            // The session for the user - contains the session token.
            ISessionInformation thisUsersSession = null; // Not yet logged on.
            try
            {
                // Step 2 - Logging on.
                // Ask the user to log on.
                thisUsersSession = SessionHelper.LogOn("Sample SDK Application", "localhost", "Admin", "Password1");

                if (thisUsersSession.IsValid()) // Did we successfully log on?
                {

                    // Retrieve all the items from the complete hierarchy
                    IItemService itemService = thisUsersSession.NewItemService();
                    if (itemService != null)
                    {
                        // Step 3 - Retrieving Asset and Model Information
                        List<ItemMinimal> items = itemService.GetItemsHierarchy(
                            thisUsersSession.Token,
                            InstanceHierarchyLevel.AssetLevel, //Can ask for model info here
                            false);

                        // Make use of the result here.
                        foreach (ItemMinimal item in items)
                        {
                            //Write out all the asset information
                            Console.WriteLine(
                                "Asset '" + item.Name +
                                "' retrieved with Guid " + item.Id +
                                " and parent Guid " + item.ParentId);
                        }
                    }

                    // Step 4 - Retrieving Advisories and Observations
                    IIncidentService incidentService = thisUsersSession.NewService<IIncidentService>();
                    IChartService chartService = thisUsersSession.NewService<IChartService>();
                    if (incidentService != null && chartService != null)
                    {
                        // Step 4.1 - Retrieving Non-Dismissed Advisories
                        List<Incident> incidents = incidentService.FindIncidentsNonDismissed(thisUsersSession.Token);

                        // Make use of the result here.
                        foreach (Incident incident in incidents)
                        {
                            Console.WriteLine(
                                "Incident '" + incident.Message +
                                " with latest priority " + incident.LatestPriority +
                                "' retrieved with Guid " + incident.InstanceGuid +
                                " and related asset '" + incident.Asset.Name + "'");

                            // Step 4.2 - Retrieving observations for the advisories if bound to a tag
                            // Get the observations for the associated asset or model.
                            Guid relatedTagId = Guid.Empty;
                            if (incident.AssetTagId != Guid.Empty)
                                relatedTagId = incident.AssetTagId;
                            if (incident.ModeledTagId != Guid.Empty)
                                relatedTagId = incident.ModeledTagId;

                            //Get the observations if the tag is not empty.
                            if (relatedTagId != Guid.Empty)
                            {
                                List<Observation> observations = chartService.GetObservations(
                                    thisUsersSession.Token,
                                    relatedTagId,
                                    incident.FirstOccurred,
                                    incident.LastOccurred);

                                //Use the results here.
                                Console.WriteLine(
                                    " --- Retrieved " + 
                                    observations.Count + 
                                    " observations for this incident.");
                            }
                        }

                        // Step 5.1 - Retrieving Diagnostic Advisories
                        // For the diagnostic advisories, we use a slightly more detailed call to retrieve the special structure.
                        // Note: This is a subset of the incidents above, so we use the diagnostic's incidentId to relate 
                        // the two sets for all the relevant information.
                        // For this call, we wil retrieve all diagnostic incidents that updated in the last year.
                        List<DiagnosticIncident> diagnosticIncidents =
                            incidentService.GetDiagnosticIncidentsUpdatedAfterDate(
                            thisUsersSession.Token, DateTime.Now.AddDays(-365));

                        foreach (DiagnosticIncident diagnosticIncident in diagnosticIncidents)
                        {
                            // Step 5.2 - Finding the Related, Non-Dismissed Advisory
                            // Look up the related incident in the list of incidents (diagnostic incidents are a subset of 
                            // the full incident list) - if they are in the incidents list, they have not been dismissed.
                            Incident relatedIncident = null;
                            foreach (Incident incident in incidents)
                                if (incident.Id == diagnosticIncident.IncidentId)
                                {
                                    relatedIncident = incident;
                                    break;
                                }


                            // If the diagnostic event has not been dismissed, then it has a related incident 
                            // in the original Incident list.
                            if (relatedIncident != null)
                            {
                                Console.WriteLine(
                                    "Retrieving observations for the tags participating " +
                                    " in the diagnostic advisory '" + relatedIncident.Message + "':");

                                // Step 5.3 - Getting Observations, Drawing Charts, and Exporting Data
                                // Get the observations for the tags contributing in the diagnostic incident.
                                foreach (ContributingTag tag in diagnosticIncident.ContributingTags)
                                {
                                    // Step 5.3.1 - Getting the observations
                                    // Get the observations for the tag over the interesting range
                                    List<Observation> observations = chartService.GetObservations(
                                        thisUsersSession.Token,
                                        tag.TagId,
                                        relatedIncident.FirstOccurred,
                                        relatedIncident.FirstOccurred.AddDays(3));

                                    // Use the results here.
                                    Console.WriteLine(
                                        " --- Retrieved " + observations.Count +
                                        " observations for the tag '" + tag.Name +
                                        "' which contributed in the diagnostic incident '" +
                                        relatedIncident.Message + "'.");

                                    // Step 5.3.2 - Drawing a chart of the tag
                                    ChartView chartView = ChartView.None;

                                    var args = ChartHelper.NewChartArgsWithDefaultValues(
                                        thisUsersSession.Token.Session,
                                        tag.TagId, //Use the tag id.
                                        chartView);

                                    args.IncludeData = true;
                                    args.WidthInPixels = 1000;
                                    args.HeightInPixels = 500;
                                    args.UseLastObservationDate = true;
                                    args.StartDate = relatedIncident.FirstOccurred;
                                    args.EndDate = args.StartDate.AddDays(2);
                                    args.ShowPointsOnXAxis = false;

                                    // Get the chart response
                                    ChartResponse chartResponse = chartService.GetSpecified(thisUsersSession.Token, args);
                                    chartResponse.Decompress();

                                    // Step 5.3.4 - Exporting the chart and image and the observations to Excel

                                    // Saving the chart response to an image
                                    var theImage = chartResponse.GetImage();
                                    var ms = new System.IO.MemoryStream();
                                    theImage.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                                    ms.Position = 0;
                                    byte[] data = ms.ToArray();
                                    ms.Close();
                                    using (System.IO.FileStream sw = new System.IO.FileStream(
                                        tag.DisplayName + "_" + observations.Count + "_observations.jpeg", 
                                        System.IO.FileMode.Create))
                                    {
                                        sw.Write(data, 0, data.Length);
                                    }

                                    // Exporting the chart data to Excel
                                    bool exported = chartResponse.ExportToExcel();
                                    if (!exported)
                                        Console.WriteLine(
                                            "Failed to export the data for the chart "
                                            + tag.DisplayName);

                                }

                                //Stop once we have found one diagnostic advisory that has not been dismissed
                                break;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occurred - " + ex.Message + "\r\n" + ex.StackTrace);
            }
            finally
            {
                // No matter what happens in the program (including exceptions) try to log off.
                thisUsersSession.LogOff();

                // Complicated programs or programs that experience exceptions may not close
                // all of the connections they opened. Fortunately, this class has been keeping
                // track and will close them for you.
                ServiceConnection.CloseAllServices();
            }
        }
    }
}
