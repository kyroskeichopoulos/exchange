/*
 * Copyright (c) 2014 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.dspmicro.sql.adapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.dspmicro.machinegateway.api.adapter.IDataSubscription;
import com.ge.dspmicro.machinegateway.api.adapter.IDataSubscriptionListener;
import com.ge.dspmicro.machinegateway.api.adapter.ISubscription;
import com.ge.dspmicro.machinegateway.api.adapter.ISubscriptionMachineAdapter;
import com.ge.dspmicro.machinegateway.types.PDataNode;
import com.ge.dspmicro.machinegateway.types.PDataValue;

/**
 * 
 * @author Predix Machine Sample
 */
@SuppressWarnings("deprecation")
public class SQLDataSubscription
        implements Runnable, IDataSubscription
{
    private UUID                            uuid;
    private String                          name;
    private long                            updateIntervalMillis;
    private ISubscriptionMachineAdapter     adapter;
    //private Map<UUID, SampleDataNode>       nodes         = new HashMap<UUID, SampleDataNode>();
    private Map<String, SampleDataNode>     nodesDict     = new HashMap<String, SampleDataNode>();
    private SQLConnector					sqlcon;
    private List<IDataSubscriptionListener> listeners     = new ArrayList<IDataSubscriptionListener>();
    //private Random                          dataGenerator = new Random();
    private final AtomicBoolean             threadRunning = new AtomicBoolean();
    private static final Logger _logger = LoggerFactory.getLogger(SQLDataSubscription.class);  
    /**
     * Constructor
     * 
     * @param adapter machine adapter
     * @param subName Name of this subscription
     * @param timeoutMillis in milliseconds
     * @param nodes list of nodes for this subscription
     */
    public SQLDataSubscription(
    		ISubscriptionMachineAdapter adapter, 
    		String subName, 
    		long timeoutMillis,
            List<SampleDataNode> nodes, 
            String sqlConString)
    {
        if ( timeoutMillis > 0 )
        {
            this.updateIntervalMillis = timeoutMillis;
        }
        else
        {
            throw new IllegalArgumentException("updataInterval must be greater than zero."); //$NON-NLS-1$
        }

        if ( nodes != null && nodes.size() > 0 )
        {
            for (SampleDataNode node : nodes)
            {
                //this.nodes.put(node.getNodeId(), node);
                this.nodesDict.put(node.getName(),node);
            }
        }
        else
        {
            throw new IllegalArgumentException("nodes must have values."); //$NON-NLS-1$
        }
        //_logger.info("1 after checks for " + subName);
        this.adapter = adapter;

        // Generate unique id.
        this.uuid = UUID.randomUUID();
        this.name = subName;

        // set SQL connection
        sqlcon = new SQLConnector(sqlConString);
        
        // Initialize random data generator.
        // this.dataGenerator.setSeed(Calendar.getInstance().getTimeInMillis());
        
        this.threadRunning.set(false);
        //_logger.info("3 after running set");
    }

    @Override
    public UUID getId()
    {
        return this.uuid;
    }

    @Override
    public String getName()
    {
        return this.name;
    }

    @Override
    @Deprecated
    public int getUpdateInterval()
    {
        return (int) (this.updateIntervalMillis / 1000L);
    }
    /* (non-Javadoc)
     * @see com.ge.dspmicro.machinegateway.api.adapter.ISubscription#getUpdateIntervalMillis()
     */
    @Override
    public long getUpdateIntervalMillis()
    {
        return this.updateIntervalMillis;
    }

    @Override
    public List<PDataNode> getSubscriptionNodes()
    {
        return new ArrayList<PDataNode>(this.nodesDict.values());
    }

    /**
     * @param listener callback listener
     */
    @Override
    public synchronized void addDataSubscriptionListener(IDataSubscriptionListener listener)
    {
        if ( !this.listeners.contains(listener) )
        {
            this.listeners.add(listener);
        }
    }

    /**
     * @param listener callback listener
     */
    @Override
    public synchronized void removeDataSubscriptionListener(IDataSubscriptionListener listener)
    {
        if ( this.listeners.contains(listener) )
        {
            this.listeners.remove(listener);
        }
    }

    /**
     * get all listeners
     * 
     * @return a list of listeners.
     */
    @Override
    public synchronized List<IDataSubscriptionListener> getDataSubscriptionListeners()
    {
        return this.listeners;
    }

    /**
     * Thread to generate random data for the nodes in this subscription.
     */
    @Override
    public void run()
    {
    	//_logger.info("11 in run");
        if ( !this.threadRunning.get() && this.nodesDict.size() > 0 )
        {
        	//_logger.info("12 set to run");
            this.threadRunning.set(true);

            while (this.threadRunning.get())
            {
            	//_logger.info("13 get successful in run");
            	List<PDataValue> data ; //= new ArrayList<PDataValue>();
            	
            	// start demo
                // Generate random data for each node and push data update.
                /*
                for (SampleDataNode node : this.nodes.values())
                {
                    // Simulating the data.
                	QualityEnum qw = null;
                    PEnvelope envelope = new PEnvelope(this.dataGenerator.nextFloat());
                    PDataValue value = new PDataValue(node.getNodeId(), envelope);
                    value.setNodeName(node.getName());
                    value.setAddress(node.getAddress());

                    QualityEnum qty = null;
					qty = QualityEnum.GOOD;
					PQuality dq = new PQuality(qty);
					value.setQuality(dq);
					
                    _logger.info("14 in run, adding " + node.getName() + ", " + node.getAddress());
                    data.add(value);
                }
                */
                // end demo
                
            	// get data
            	data = getTagValues(this.nodesDict,this.name);
            	
                // Writing the simulated data into cache
                ((SQLSubscriptionMachineAdapterImpl) this.adapter).putData(data);
                
                //Provide the subscription name as a property of the data. If the data is being
                //published on the databus river, the subscription name will be used as the publish topic
            	HashMap<String,String> properties = new HashMap<String,String>();
            	properties.put(ISubscription.PROPKEY_SUBSCRIPTION, this.name);

                for (IDataSubscriptionListener listener : this.listeners)
                {
                	_logger.info("15 in run, listener " + listener.toString());
                    listener.onDataUpdate(this.adapter, properties, data);
                }

                try
                {
                    // Wait for an updateInterval period before pushing next data update.
                    Thread.sleep(getUpdateIntervalMillis());
                }
                catch (InterruptedException e)
                {
                    // ignore
                }
            }
        }
    }

    /**
     * Stops generating random data.
     */
    public void stop()
    {
    	//_logger.info("1 in stop");
        if ( this.threadRunning.get() )
        {
            this.threadRunning.set(false);
            //_logger.info("2 in stop, set to false");
            // Send notification to all listeners.
            for (IDataSubscriptionListener listener : this.listeners)
            {
            	_logger.info("in stop, listener " + listener.toString());
                listener.onSubscriptionDelete(this.adapter, this.uuid);
            }

            // Do other clean up if needed...
        }
    }
    
    private List<PDataValue> getTagValues(Map<String, SampleDataNode> tags, String pattern)
    {
    	List<PDataValue> data = null;
    	try
    	{
    		 data = sqlcon.getTagValues(tags,pattern);
    		 _logger.info("count is : " + data.size());
    		 for(PDataValue dv: data)
    		 {
    			 _logger.info("value is : " + 
    					 	  dv.getNodeName() + " " + 
    					 	  dv.getTimestamp().getTimeMilliseconds() + " " + 
    					 	  dv.getValue().getValue() + " " + 
    					 	  dv.getQuality().getQualityEnum().name());
    		 }
    	}
    	catch(Exception e)
    	{
    		_logger.info("error in gettagvalues!");
    		e.printStackTrace();
    		_logger.error(e.getMessage());
    	}
    	return data;
    }
}
