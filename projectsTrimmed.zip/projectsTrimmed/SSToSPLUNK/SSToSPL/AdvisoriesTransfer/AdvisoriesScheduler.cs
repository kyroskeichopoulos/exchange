﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Configuration;
using System.IO;
using AdvisoriesQueries;
using AdvisoriesTransformer;
using RetrievalState;

[assembly: log4net.Config.XmlConfigurator(Watch = true)]

namespace AdvisoriesTransfer
{
    class AdvisoriesScheduler
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        //private static readonly log4net.ILog log = LogHelper.GetLogger();

        #region variables

        private Timer advTimer = null;

        private Transform advT;
        private Queries advQ;
        private AssetQueryState qs;
        
        private string filepath;
        private string filetype;
        private string fileformat;
        private string AVDBCon;
        private string appPath;

        private string SSappName;
        private string SShost;
        private string SSuser;
        private string SSpwd;

        #endregion

        #region constructor and events

        public AdvisoriesScheduler()
        {
            advTimer = new Timer();
            double timerInterval = Convert.ToDouble(ConfigurationManager.AppSettings["interval"])*1000*60;
            advTimer.Interval = timerInterval;
            advTimer.AutoReset = true;
            advTimer.Elapsed += new ElapsedEventHandler(advTimer_Elapsed);
            IntializeObjects();
        }

        private void advTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            //retrieveAdvisoriesPerAsset();
            retrieveLastUpdatedAdvisories();
        }

        public void Start()
        {
            qs.ReadQueryStates();
            qs.ReadLastQueryTime();
            advTimer.Enabled = true;
        }

        public void Stop()
        {
            log.Debug("exiting......");
            advTimer.Enabled = false;
            qs.PersistQueryStates();
            qs.PersistLastQueryTime();
            try
            {
                advQ.Disconnect();
            }
            catch(Exception e)
            {
                log.Error("failed to close connect to SS server. Reason: " + e.Message, e);
            }
        }

        #endregion

        #region methods

        private void IntializeObjects()
        {
            log.DebugFormat("entry at {0}", DateTime.Now.ToString("yyyyMMddHHmmss"));
            // get config settings
            filepath = ConfigurationManager.AppSettings["filePath"];
            filetype = ConfigurationManager.AppSettings["fileType"];
            fileformat = ConfigurationManager.AppSettings["fileFormat"];
            AVDBCon = ConfigurationManager.ConnectionStrings["AVConnStr"].ConnectionString;
            appPath = Path.GetDirectoryName(System.AppDomain.CurrentDomain.BaseDirectory);

            // get connection setting to Smart Signal web server
            SSappName = ConfigurationManager.AppSettings["appName"];
            SShost = ConfigurationManager.AppSettings["host"];
            SSuser = ConfigurationManager.AppSettings["user"];
            SSpwd = ConfigurationManager.AppSettings["password"];

            // init helper objects
            advT = new Transform(log, filepath, filetype, AVDBCon);
            advQ = new Queries(log,SSappName,SShost,SSuser,SSpwd);
            qs = new AssetQueryState(appPath);
        }

        private void retrieveLastUpdatedAdvisories()
        {
            string result = "";
            List<returnedSet> lrs = null;

            DateTime thisTime = DateTime.Now;
            DateTime sinceTime = DateTime.Now;
            sinceTime = qs.retrieveQueryTime(sinceTime);
            if (thisTime.Subtract(sinceTime).TotalSeconds > 1)
            {
                // get advisories updates since last query time
                try
                {
                    lrs = advQ.GetAdvisories(sinceTime);
                }
                catch (Exception e)
                {
                    log.Error("failed to retrieve advisories. Reason: " + e.Message, e);
                }
                
                if(lrs == null)
                {
                    log.Warn("No advisories object instantiated");
                    return;
                }
                // get list of assets
                List<string> assets = lrs.Select(x => x.Asset).Distinct().ToList();
                // save files for every asset
                foreach (string asset in assets)
                {
                    List<returnedSet> advAsset = lrs.Where(x => x.Asset == asset).ToList();
                    if(advAsset.Count > 0)
                    {
                        result = advT.ToFile(advAsset, fileformat);
                        if (result.Length > 0)
                        {
                            log.Error("failed to save advisories for asset " + asset + ". Reason: " + result);
                        }
                    } // if advisories for asset returned
                } // for every asset
            } // if not first time it runs

            // set this time as last query time
            qs.lastQueryTime = thisTime;
        }

        #endregion

        /*
        private void retrieveAdvisoriesPerAsset()
        {
            string result = "";
            DateTime startTime = DateTime.Now;
            // get assets
            List<string> assets = advQ.GetAssets();
            // get advisories for every asset
            foreach (string asset in assets)
            {
                List<returnedSet> lrs = null;
                DateTime lastTS = qs.retrieveQueryTime(asset, startTime);
                if (startTime.Subtract(lastTS).TotalSeconds > 1)
                {
                    try
                    {
                        lrs = advQ.GetAdvisories(lastTS, startTime, asset);
                    }
                    catch (Exception e)
                    {
                        log.Error("failed to retrieve advisories for asset " + asset + ". Reason: " + e.Message, e);
                        continue;
                    }
                    // save advisories
                    result = advT.ToFile(lrs, fileformat);
                    if (result.Length > 0)
                    {
                        log.Error("failed to save advisories for asset " + asset + ". Reason: " + result);
                    }
                }
                qs.writeQueryTime(asset, startTime);
            }
        }

        private void test()
        {
            log.Debug("from here " + advTimer.Interval.ToString());
            log.Debug(Path.GetDirectoryName(System.AppDomain.CurrentDomain.BaseDirectory));
            using(StreamWriter sw = new StreamWriter(@"C:\Users\113006521\Desktop\projects\SSToSPLUNK\SSToSPL\test.txt",true))
            {
                sw.WriteLine(DateTime.Now.ToString("yyMMdd HHmmss"));
            }
        }
         */
    }
}
