﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using log4net;

namespace DBServices
{
    public class AssetData
    {
        private string _classname = "AssetData: ";
        private log4net.ILog _logger;
        private string _conStr;
        public string connectionString
        {
            get { return _conStr; }
            set { _conStr = value; }
        }

        public AssetData(log4net.ILog logger, string connStr)
        {
            _logger = logger;
            _conStr = connStr;
        }

        public string GetBR(string LokNr)
        {
            string _br = "";
            if(_conStr.Length == 0)
            {
                _logger.Warn(_classname + "no connection string  provided");
                return LokNr;
            }

            using(SqlConnection con = new SqlConnection(_conStr))
            {
                using(SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = con;
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = sp_names.getBR;
                    cmd.Parameters.Add("@LokNr", SqlDbType.VarChar, 25).Value = LokNr;
                    try
                    {
                        con.Open();
                        using(SqlDataReader dr = cmd.ExecuteReader())
                        {
                            if(dr.HasRows)
                            {
                                while(dr.Read())
                                {
                                    _br = dr[0].ToString();
                                }
                            }
                            else
                            {
                                _logger.Warn(_classname + "no Baureihe found for LokNr " + LokNr);
                                _br = LokNr;
                            }
                        } //dr
                    }
                    catch(Exception e)
                    {
                        _logger.Error(_classname + "failure reading from connection" + _conStr, e);
                        if (con.State == ConnectionState.Open) con.Close();
                        throw new ApplicationException("failure reading from connection");
                    }
                } // cmd
            } // con
            return _br;
        }
    }
}
