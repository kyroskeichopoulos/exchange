﻿// Copyright 2009-2010 SmartSignal Corporation
// For customer and partner use with SmartSignal products
// http://www.smartsignal.com/

using System;
using System.Windows.Forms;
using SmartSignal.Com.EPICenter.Service.Client;
using SmartSignal.Com.EPICenter.Service.Common;
using SmartSignal.Com.EPICenter.Service.Contract;

// This sample program:
// 1. Logs on.
// 2. Gets assets, modes, models, and model tags.
// 3. Sorts them.
// 4. Outputs each model tag with its parent asset, mode, and model.
// 5. Logs off.

namespace ModelsAndTags
{
	class Program
	{
		// Start with all the standard Microsoft stuff.
		[STAThread]
		static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);

			// Now here's the SmartSignal stuff.
			ISessionInformation thisUsersSession = null; // Not yet logged on.

			try
			{
				Console.WriteLine("1. Logging on");

				// Ask the user to log on.
			    thisUsersSession = SessionHelper.LogOn("MyApp", "localhost", "JaneDoe", "password");
				// FYI: You can use command line parameters instead, if desired.
				// This allows you to schedule a program to automatically logon.

				if (thisUsersSession.IsValid()) // Did we successfully log on?
				{
					Console.WriteLine("2. Getting items. Please wait...");

					// Ask the SmartSignal helper library to connect to the Item service and
					// return all asset, mode, model, and model tag items from this server. 
					var items = thisUsersSession.GetItemsByCategory(ItemCategory.InstanceEntity,
					                                                ItemCategory.InstanceMode,
					                                                ItemCategory.InstanceModel,
					                                                ItemCategory.InstanceModelTag);

					if (items != null && items.Count > 0) // Did we successfully obtains some items?
					{
						Console.WriteLine("3. Sorting");

						// Sort them.
						items = items.AlphabetizeByParent();

						// Lists of items are fine, but large servers may contain 100,000 or more items.
						// Let's create an indexed search of those items, so that we can lookup the
						// parent paths quickly.
						var fastLookup = items.CreateFastLookup();

						Console.WriteLine("4. Output");

						Console.WriteLine("ASSET\tMODE\tMODEL\tMODEL TAG");

						// Display each item.
						foreach (var item in items)
						{
							// Do we have a model tag item?
							if (item != null && item.Category == ItemCategory.InstanceModelTag)
							{
								// Find the parents.
								var parents = fastLookup.Parents(item);

								if (parents != null) // Yes, we have parents.
								{
									foreach (var parent in parents)
									{
										if (parent != null) // If this is a valid parent...
										{
											// Output the name, followed by a tab character.
											Console.Write("{0}\t", parent.Name);
											// Instead of writing to the screen, you could write to a file.
											// Excel can import tab-delimited files.
										}
									}
								}

								// At the end of the line, output the name of the model tag.
								Console.WriteLine(item.Name);
							}
						}
					}
				}
			}
			finally
			{
				Console.WriteLine("5. Logging off");

				// No matter what happens in the program (including exceptions) try to logoff.
				thisUsersSession.LogOff();

				// Complicated programs or programs that experience exceptions may not close
				// all of the connections they opened. Fortunately, this class has been keeping
				// track and will close them for you.
				ServiceConnection.CloseAllServices();
			}

#if DEBUG
			Console.WriteLine();
			Console.WriteLine("Press a key to exit.");
			Console.ReadKey();
#endif
		}
	}
}
