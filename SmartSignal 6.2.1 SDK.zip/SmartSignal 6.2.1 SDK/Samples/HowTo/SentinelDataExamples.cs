// Copyright � 2012 SmartSignal Corporation
// For customer and partner use with SmartSignal products
// http://www.smartsignal.com/

using System;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.ServiceModel;
using System.Windows.Forms;
using SmartSignal.Com.Common;
using SmartSignal.Com.EPICenter.Service.Common;
using SmartSignal.Com.EPICenter.Service.Contract;

namespace HowTo
{
	/// <summary>
	/// Examples demonstrating how to get various pieces of data that are shown in the Sentinel application. 
	/// </summary>
    public class SentinelDataExamples
    {
        /// <summary>
        /// Given a tag ID and a UTC date range, this example demonstrates how to retrieve incident event information.
        /// </summary>
        /// <param name="token">Valid session token</param>
        /// <param name="tagId">ID of the asset tag or model tag whose data will be retrieved</param>
        /// <param name="startDateUtc">Start date in UTC time zone of the range of data</param>
        /// <param name="endDateUtc">End date in UTC time zone of the range of data</param>
        public static void GetTagChartData(SessionToken token, Guid tagId, DateTime startDateUtc, DateTime endDateUtc)
        {
            IChartService service = null;

            try
            {
                // Use the helper to create an IChartService.
                service = token.Create<IChartService>();

                // Put together arguments for the information to retrieve.
                var args = new ChartArgs
                               {
                                   IncludeData = true,
                                   IncludeImage = false,
                                   ItemId = tagId,
                                   StartDate = startDateUtc,
                                   EndDate = endDateUtc,
                               };

                // Use the chart service's gereralized "GetSpecified" call to get a general ChartResponse populated
                // based on the parameters above.
                ChartResponse response = service.GetSpecified(token, args);
                if (response == null)
                {
                    // TODO: error handling/reporting
                }
                else if (response.IncidentEventsByIds != null)
                {
                    // Loop through each container for incident events. See IncidentEventsById for
                    // more information on what all it contains.
                    foreach (IncidentEventsById eventsContainer in response.IncidentEventsByIds)
                    {
                        if (eventsContainer != null && eventsContainer.IncidentEvents != null)
                        {
                            // Here we are down to looping through individual incident events.
                            foreach (IncidentEvent incidentEvent in eventsContainer.IncidentEvents)
                            {
                                // TODO: Console write is for example only, do actual logic with the incident event here.
								// You might also decide to collect this data and return it from this method in order to keep
								// this method general.
                                Console.WriteLine(@"Incident event occurred at: " + incidentEvent.ObservationDate);
                            }
                        }
                    }
                }
            }
            finally
            {
                service.Close();
            }
        }
    }
}
