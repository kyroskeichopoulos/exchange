﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace MoveFiles
{
    public partial class MoveFilesService : ServiceBase
    {
        private MoveScheduler mvScheduler;
        public MoveFilesService()
        {
            InitializeComponent();
            mvScheduler = new MoveScheduler();
        }

        protected override void OnStart(string[] args)
        {
            mvScheduler.Start();
        }

        protected override void OnStop()
        {
            mvScheduler.Stop();
        }

        //for debugging
        public void OnStart_Debug()
        {
            OnStart(null);
        }
        public void OnStop_Debug()
        {
            OnStop();
        }

    }
}
