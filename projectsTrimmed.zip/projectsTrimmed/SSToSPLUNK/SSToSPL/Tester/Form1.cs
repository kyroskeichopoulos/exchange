﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AdvisoriesQueries;
using AdvisoriesTransformer;
using System.Configuration;
using RetrievalState;
using System.IO;

[assembly: log4net.Config.XmlConfigurator(Watch = true)]

namespace Tester
{
    public partial class Form1 : Form
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            log.DebugFormat("entry at {0}", DateTime.Now.ToString("yyyyMMddHHmmss"));
            string result = "";
            // get config settings
            string filepath = ConfigurationManager.AppSettings["filePath"];
            string filetype = ConfigurationManager.AppSettings["fileType"];
            string fileformat = ConfigurationManager.AppSettings["fileFormat"];
            string AVDBCon = ConfigurationManager.ConnectionStrings["AVConnStr"].ConnectionString;

            this.Text = "done " + DateTime.Now.ToString("HHmmss");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string appPath = Path.GetDirectoryName(System.AppDomain.CurrentDomain.BaseDirectory);
            AssetQueryState qs = new AssetQueryState(appPath);

            qs.ReadQueryStates();

            DateTime ts = DateTime.Now;
            string newasset1 = "660035";
            DateTime newasset1ts = qs.retrieveQueryTime(newasset1, ts);

            newasset1ts = newasset1ts.AddHours(-5);
            qs.writeQueryTime(newasset1, newasset1ts);

            newasset1ts = qs.retrieveQueryTime(newasset1, ts);

            newasset1 = "670035";
            newasset1ts = newasset1ts.AddHours(-15);
            qs.writeQueryTime(newasset1, newasset1ts);

            qs.PersistQueryStates();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DirectoryInfo d = new DirectoryInfo(@"C:\outputs");//Assuming Test is your Folder
            FileInfo[] Files = d.GetFiles("*.zip"); //Getting Text files
            string str = "";
            double threshold = 30;
            foreach (FileInfo file in Files)
            {
                str = file.Name;
                TimeSpan diff = DateTime.Now - file.CreationTime;
                if(diff.TotalSeconds > threshold)
                System.Diagnostics.Debug.WriteLine(str + " " + file.CreationTime.ToLongTimeString() + " " + file.LastWriteTime.ToLongTimeString());
            }
        }
    }
}
