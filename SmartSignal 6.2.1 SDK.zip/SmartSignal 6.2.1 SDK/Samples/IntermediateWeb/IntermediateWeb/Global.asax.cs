﻿using System;
using SmartSignal.Com.EPICenter.Service.Common;
using SmartSignal.Com.EPICenter.Service.Web;

namespace IntermediateWeb
{
	public class Global : System.Web.HttpApplication
	{
		protected void Application_Start(object sender, EventArgs e)
		{

		}

		protected void Session_Start(object sender, EventArgs e)
		{

		}

		protected void Application_BeginRequest(object sender, EventArgs e)
		{

		}

		protected void Application_AuthenticateRequest(object sender, EventArgs e)
		{

		}

		protected void Application_Error(object sender, EventArgs e)
		{

		}

		protected void Session_End(object sender, EventArgs e)
		{
			WebServiceConnection.LogOff(Session);
		}

		protected void Application_End(object sender, EventArgs e)
		{

		}
	}
}