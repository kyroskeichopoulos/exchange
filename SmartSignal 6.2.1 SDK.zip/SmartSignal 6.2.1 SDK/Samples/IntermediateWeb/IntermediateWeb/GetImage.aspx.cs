﻿// Copyright © 2010 SmartSignal Corporation
// For customer and partner use with SmartSignal products
// http://www.smartsignal.com/

// Comment out this next line if you want to goof around and see all of the raw data returned in the debugger.
//#define INCLUDE_DATA

using System;
using System.Drawing.Imaging;
using System.Globalization;
using SmartSignal.Com.Common;
using SmartSignal.Com.EPICenter.Service.Common;
using SmartSignal.Com.EPICenter.Service.Contract;
using SmartSignal.Com.EPICenter.Service.Web;

namespace IntermediateWeb
{
	/// <summary>
	/// Supports dynamic return of product logos, customer logos, and chart images, without have them saved to the disk on the server.
	/// 1. Place an image control on the page.
	/// 2. Make sure that the log on is succesful and the session information is saved.
	/// 3. Call GetImage.Setup.
	/// When the page is received by the browser, the chart image will be requested.
	/// </summary>
	public partial class GetImage : System.Web.UI.Page
	{
		/// <summary>
		/// Given an ASP.NET image control, sets the url, dimensions, and default alt text for displaying a chart.
		/// Feel free to put better alt text after making this call.
		/// </summary>
		public static void Setup(System.Web.UI.WebControls.Image image, Guid chartId, ChartView chartView)
		{
			Setup(image, chartId, chartView, false, false, DateTime.MinValue, DateTime.MaxValue, false);
		}

		/// <summary>
		/// Given an ASP.NET image control, sets the url, dimensions, and default alt text for displaying a chart.
		/// Feel free to put better alt text after making this call.
		/// </summary>
		public static void Setup(System.Web.UI.WebControls.Image image, Guid chartId, ChartView chartView,
									Boolean showResidualsSeparately, Boolean showPointsOnXAxis,
									DateTime startDate, DateTime endDate, Boolean useLastObservationDate )
		{
			if (image != null)
			{
				image.ImageUrl = "GetImage.aspx?"
				                 + LinkKey.ItemId + "=" + chartId
								 + "&" + LinkKey.ChartView + "=" + chartView;

				if (startDate != DateTime.MinValue && startDate != DateTime.MaxValue)
				{
					image.ImageUrl += "&" + LinkKey.StartDate + "=" + String.Format(CultureInfo.InvariantCulture, "{0:u}", startDate);
				}

				if (endDate != DateTime.MinValue && endDate != DateTime.MaxValue)
				{
					image.ImageUrl += "&" + LinkKey.EndDate + "=" + String.Format(CultureInfo.InvariantCulture, "{0:u}", endDate);
				}
				
				var options = String.Empty;

				if ( showResidualsSeparately )
				{
					options.Suffix(LinkValue.OptionsSeparator);
					options += LinkValue.ChartOptionsShowResidualsSeparately;
				}

				if (useLastObservationDate)
				{
					options.Suffix(LinkValue.OptionsSeparator);
					options += LinkValue.ChartOptionsUseLastObservationDate;
				}

				if (showPointsOnXAxis)
				{
					options.Suffix(LinkValue.OptionsSeparator);
					options += LinkValue.ChartOptionPoints;
				}

				// put more options here.

				if ( String.IsNullOrEmpty(options)==false)
				{
					image.ImageUrl += "&" + LinkKey.ChartOptions + "=" + options;
				}

				int heightInPixels;
				int widthInPixels;
				chartView.GetDimensions(showResidualsSeparately, out heightInPixels, out widthInPixels);

				image.Height = heightInPixels;
				image.Width = widthInPixels;

				image.AlternateText = StringHelper.Format(CultureInfo.CurrentCulture, Resources.ChartImageAlternateTextDefault,
														  chartId, chartView);
			}
		}

		[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
		protected void Page_Load(object sender, EventArgs e)
		{
			try
			{
				// This only works for logged on users.
				var existingSessionInfo = Session[WebServiceConnection.SessionInfoKey] as SessionInformation;

				if (existingSessionInfo != null)
				{
					// Find out what chart they want.
					var chartId = Request.QueryStringSafe(LinkKey.ItemId, Guid.Empty);

					if (chartId != Guid.Empty)
					{
						// Find out what view they want. (Defaults to DaySmall if not otherwise specified.)
						var chartView = Request.QueryStringSafeEnum(LinkKey.ChartView, ChartView.DaySmall);

						var startDate = Request.QueryStringSafeEnum(LinkKey.ChartView, DateTime.MinValue);
						var endDate = Request.QueryStringSafeEnum(LinkKey.ChartView, DateTime.MaxValue);

						var options = Request.QueryStringSafe(LinkKey.ChartOptions);

						var showResidualsSeparately = false;
						var useLastObservationDate = false;
						var showPointsOnXAxis = false;

						if ( String.IsNullOrEmpty(options)==false)
						{
							showResidualsSeparately = options.Contains(LinkValue.ChartOptionsShowResidualsSeparately);
							useLastObservationDate = options.Contains(LinkValue.ChartOptionsUseLastObservationDate);
							showPointsOnXAxis = options.Contains(LinkValue.ChartOptionPoints);
						}

						ChartResponse chartResponse;

						if (	( startDate > DateTime.MinValue && startDate < DateTime.MaxValue )
							 || ( endDate > DateTime.MinValue && endDate < DateTime.MaxValue )
							 || showResidualsSeparately
							 || useLastObservationDate
							 || showPointsOnXAxis )
						{
							// Connect to the chart service.
							var chartService = existingSessionInfo.Token.NewChartService();

							var args = ChartHelper.NewChartArgsWithDefaultValues(existingSessionInfo, chartId, chartView);
#if INCLUDE_DATA
							args.IncludeData = true;
#endif
							args.UseLastObservationDate = useLastObservationDate; // Server will find the most recent data, as opposed to honoring your start date.
							args.EndDate = endDate;
							args.StartDate = startDate;
							args.ShowResidualsSeparately = showResidualsSeparately;

							if (showResidualsSeparately)
							{
								args.ShowResiduals = ShowSeries.All;
							}

							args.ShowPointsOnXAxis = showPointsOnXAxis;

							chartResponse = chartService.GetSpecified(existingSessionInfo.Token, args);
							chartResponse.Decompress();
							// Check out:
							// chartResponse.Diagnostics();
							// chartResponse.ItemPath;
							// chartResponse.Items;
							// chartResponse.ObservationsByIds;
							// chartResponse.IncidentEventsByIds;
							// chartResponse.MostRecentObservationSummary;
							// chartResponse.RuntimeEventsByIds;
							chartService.Close();
						}
						else
						{
							// Get the chart.
							chartResponse = ChartHelper.GetImageByViewWithCache(null, existingSessionInfo, chartId, chartView);	
						}
							
						// Extract the image.
						var hereIsTheImage = chartResponse.GetImage();

						if (hereIsTheImage != null)
						{
							// Send back the image.
							Response.ContentType = "image/png";
							hereIsTheImage.Save(Response.OutputStream, ImageFormat.Png);
							Response.Flush();
						}
					}
				}
			}
// ReSharper disable EmptyGeneralCatchClause
			catch
// ReSharper restore EmptyGeneralCatchClause
			{

			}
		}
	}
}
