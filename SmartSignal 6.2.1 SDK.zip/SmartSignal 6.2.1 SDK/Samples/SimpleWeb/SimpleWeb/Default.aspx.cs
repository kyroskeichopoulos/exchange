﻿// Copyright 2010 SmartSignal Corporation
// For customer and partner use with SmartSignal products
// http://www.smartsignal.com/

using System;
using System.Globalization;
using SmartSignal.Com.Common;
using SmartSignal.Com.EPICenter.Service.Common;
using SmartSignal.Com.EPICenter.Service.Contract;

namespace SimpleWeb
{
	/// <summary>
	/// This sample web application demonstrates:
	/// 1. Logging on with a fixed name and password (although you could use a real name and password in a sign on page)
	/// 2. Connecting to another service and making a method call.
	/// 3. Always logging off and closing connections.
	/// 4. Storing strings in a resource file to make them localizable.
	/// </summary>
    public partial class DefaultPage : System.Web.UI.Page
    {
		// Change as needed for your specific server and account.
		private const string ServerAddress = "localhost";
		private const string ServerPort = "80";
		private const string UserName = "JaneDoe";
		private const string Password = "password";

    	protected void Page_Load(object sender, EventArgs e)
        {
			// This code is simple and easy.
			// The problem with this simple example is that it logs on and logs off every time the page is hit.
			// That means the Gatekeeper connections windows is going to show page after page of logons, rather
			// than reusing a user's logon until their ASP.NET session ends.
			// See the IntermediateWeb example for code that saves the logon for as long as the ASP.NET session is around.
			
			var session = ServiceConnection.LogOnSimple(UserName, Password, ServerAddress, ServerPort);

			try
			{
				if ( session.IsValidSession()==false)
				{
					LogOnResult.Text = StringHelper.Format(CultureInfo.CurrentCulture, Resources.LogOnFailedResultCode, session.Reason());
				}
				else
				{
					LogOnResult.Text = Resources.LogOnSuccessful;

					DoMyPageLoadStuff(session);	
				}
			}
			catch ( Exception ex)
			{
				LogOnResult.Text = StringHelper.Format(CultureInfo.CurrentCulture, Resources.UnexpectedError, ex.Message);
			}
			finally
			{
				// Always log off, no matter what happened.
				session.LogOffSimple();
			}
        }

		private void DoMyPageLoadStuff ( SessionInformation session )
		{
			// We can assume we are logged on with a valid session and service object at this point.
			// The parameter userService is not being used in this sample.
			// However, we are passing it to demonstrate that it is valid and usable if needed.

			InstallationInformation.Text = StringHelper.Format(CultureInfo.CurrentCulture, Resources.InstallationInformation,
			                                                   session.UserDetail.DisplayName, session.Installation.DisplayName, session.Token.Address);

			// Demonstrate how to connect to another service using this same session.
			var itemService = session.NewItemService();

			try
			{
				var assetCount = itemService.CountItemsByCategory(session.Token, ItemCategory.InstanceEntity, false);

				AssetCount.Text = StringHelper.Format(CultureInfo.CurrentCulture, Resources.AssetCount, assetCount);
			}
			catch ( Exception ex)
			{
				AssetCount.Text = StringHelper.Format(CultureInfo.CurrentCulture, Resources.UnexpectedError, ex.Message);
			}
			finally
			{
				// Always close the service when you are done with it. The extension method is safe to call even with a null.
				itemService.Close();
			}
		}
    }
}
