﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileHandling
{
    public class FilesToMove
    {
        private string filepath;

        //use with retrieveFilesSent
        private string filenameFilesToMove = "FilesSent.txt";
        private List<string> _filesToMove;
        public List<string> lstFilesToMove
        {
            get { return _filesToMove; }
            set { _filesToMove = value; }
        }

        public FilesToMove(string filepath)
        {
            this.filepath = filepath;
            _filesToMove = new List<string>();
        }

        public void ReadFilesSent()
        {
            if (File.Exists(Path.Combine(filepath, filenameFilesToMove)))
            {
                using (StreamReader sr = new StreamReader(Path.Combine(filepath, filenameFilesToMove)))
                {
                    while (sr.Peek() > -1)
                    {
                        string ln = sr.ReadLine();
                        _filesToMove.Add(ln);
                    }
                }
            }
        }

        public void PersistFilesSent()
        {
            using (StreamWriter sw = new StreamWriter(Path.Combine(filepath, filenameFilesToMove), false))
            {
                foreach (string fn in _filesToMove)
                {
                    sw.WriteLine(fn);
                }
            }
        }

        public bool IsSent(string filename)
        {
            int cnt = _filesToMove.Where(x => String.Equals(x, filename, StringComparison.InvariantCultureIgnoreCase)).Count();
            if (cnt == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public void AddToSentFiles(string filename)
        {
            int cnt = _filesToMove.Where(x => String.Equals(x, filename, StringComparison.InvariantCultureIgnoreCase)).Count();
            if (cnt == 0)
            {
                _filesToMove.Add(filename);
            }
        }

        public void RemoveFromSentFiles(string filename)
        {
            int cnt = _filesToMove.Where(x => String.Equals(x, filename, StringComparison.InvariantCultureIgnoreCase)).Count();
            if (cnt > 0)
            {
                _filesToMove.Remove(filename);
            }
        }
    }
}
