﻿// Copyright 2010 SmartSignal Corporation
// For customer and partner use with SmartSignal products
// http://www.smartsignal.com/

using System;
using System.Globalization;
using SmartSignal.Com.Common;
using SmartSignal.Com.EPICenter.Service.Common;
using SmartSignal.Com.EPICenter.Service.Contract;
using SmartSignal.Com.EPICenter.Service.Web;

namespace IntermediateWeb
{
	/// <summary>
	/// This sample web application demonstrates:
	/// 1. Logging on with a fixed name and password (although you could use a real name and password in a sign on page).
	/// 2. Retaining that logon session for the life of the user's ASP session.
	/// 3. Connecting to a service and making a method call.
	/// 4. Making sure a chartable object exists and then set up the page to request the chart image.
	/// 5. Always logging off and closing connections.
	/// 6. Storing strings in a resource file to make them localizable.
	/// </summary>
	
// ReSharper disable InconsistentNaming
	[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1707:IdentifiersShouldNotContainUnderscores")]
	public partial class DefaultPage : System.Web.UI.Page
// ReSharper restore InconsistentNaming
	{
		[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
		protected void Page_Load(object sender, EventArgs e)
		{
			WebServiceConnection webServiceConnection = null;

			try
			{
				webServiceConnection = LogOnManager.LogOnAsNeeded(Session, Request);
				
				// See if we have a valid logon.
				var loggedOn = webServiceConnection.IsLoggedOn;
				LogOnResult.Text = webServiceConnection.LogOnResult;

				if (loggedOn)
				{
					var sessionInformation = webServiceConnection.SessionInfo;
					var token = webServiceConnection.Token;

					// Display some information about the SmartSignal server that we're talking to.
					InstallationInformation.Text = StringHelper.Format(CultureInfo.CurrentCulture, Resources.InstallationInformation,
															   sessionInformation.UserDetail.DisplayName,
															   sessionInformation.Installation.DisplayName,
															   token.Address,
															   Resources.ApplicationName,
															   Request.ServerVariables);

					// Here is the chart we're going to request. Change this guid to something real in your server.
					var showThisChartId = LogOnManager.ExampleChart;
					const ChartView showThisChartView = ChartView.MonthLarge;

					ItemFull chartItem = null;

					try
					{
						// Demonstrate connecting to another service and making a call for the fun of it.
						var assetCount = webServiceConnection.ItemService.CountItemsByCategory(token, ItemCategory.InstanceEntity, false);

						AssetCount.Text = StringHelper.Format(CultureInfo.CurrentCulture, Resources.AssetCount, assetCount);

						// Ask about the chart guid.
						chartItem = webServiceConnection.ItemService.GetItemFull(token, showThisChartId);
					}
					catch (Exception ex)
					{
						AssetCount.Text = StringHelper.Format(CultureInfo.CurrentCulture, Resources.UnexpectedError, ex.Message);
					}

					if (chartItem == null) 
					{
						// The chart guid was invalid.
						ChartError1.Text = StringHelper.Format(CultureInfo.CurrentCulture, Resources.ChartNotFound, showThisChartId);
					}
					else if (chartItem.Category != ItemCategory.InstanceModelTag && chartItem.Category != ItemCategory.InstanceTag && chartItem.Category != ItemCategory.InstanceChart)
					{
						// The guid is valid, but not the type of thing that can be drawn on a chart.
						ChartError1.Text = StringHelper.Format(CultureInfo.CurrentCulture, Resources.ChartWrongCategory, chartItem.Category);
					}
					else
					{
						// Valid, chartable guid. Save the information to the image on this aspx page.
						GetImage.Setup(ChartImage1, showThisChartId, showThisChartView);
						ChartImage1.AlternateText = chartItem.Name; // Friendly name than the guid.
					}
				}
			}
			catch (Exception ex)
			{
				// Unexpected error.
				LogOnResult.Text = ex.Message;
			}
			finally
			{
				if (webServiceConnection != null)
				{
					// We're closing the service connections. We are NOT logging out.
					webServiceConnection.CloseAllServices();
				}
			}
		}

		protected void LogOff_Click(object sender, EventArgs e)
		{
			Session.Abandon();
		}
	}
}
