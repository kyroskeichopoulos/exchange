﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SmartSignal.Com.EPICenter.Service.Contract;
using SmartSignal.Com.EPICenter.Service.Client;
using SmartSignal.Com.EPICenter.Service.Common;

namespace AdvisoriesQueries
{
    public class Queries
    {
        #region variables

        private string _classname = "Queries: ";
        private log4net.ILog _logger;

        ISessionInformation thisUsersSession = null;
        IItemService itemService = null;
        IIncidentService incidentService = null;
        IChartService chartService = null;

        private string _ssappName;
        private string _ssHost;
        private string _ssuser;
        private string _sspwd;

        #endregion

        public Queries(log4net.ILog logger, string appName,string host,string user,string pwd)
        {
            _logger = logger;
            _ssappName = appName;
            _ssHost = host;
            _ssuser = user;
            _sspwd = pwd;
        }

        #region methods

        private bool Connect()
        {
            // create a session if none exists
            if (thisUsersSession == null)
            {
                thisUsersSession = SessionHelper.LogOnNonInteractive(_ssappName, _ssHost,
                                                                     System.Globalization.CultureInfo.CreateSpecificCulture("en-US"),
                                                                     _ssuser, _sspwd);
            }
            // check if valid
            if (!thisUsersSession.IsValid())
            {
                // if not valid, disconnect and reconnect
                Disconnect();
                System.Threading.Thread.Sleep(new TimeSpan(0, 0, 2));
                thisUsersSession = SessionHelper.LogOnNonInteractive(_ssappName, _ssHost,
                                                                     System.Globalization.CultureInfo.CreateSpecificCulture("en-US"),
                                                                     _ssuser, _sspwd);                
            }
            return thisUsersSession.IsValid();
        }

        public void Disconnect()
        {
            //_logger.Debug("before log off");
            //thisUsersSession.LogOff();
            //SessionHelper.LogOff(thisUsersSession);
            thisUsersSession.LogOffSimple();
            //_logger.Debug("before close all");
            ServiceConnection.CloseAllServices();
            itemService = null;
            incidentService = null;
            chartService = null;
            thisUsersSession = null;
        }

        /// <summary>
        /// use with retrieveLastUpdatedAdvisories
        /// </summary>
        /// <param name="updatedSince"></param>
        /// <returns></returns>
        public List<returnedSet> GetAdvisories(DateTime updatedSince)
        {
            List<returnedSet> retlist = null;

            try
            {
                if(Connect())
                {
                    // do stuff here
                    if(retlist == null)
                    {
                        retlist = new List<returnedSet>();

                        #region add samples

                        retlist.Add(new returnedSet
                        {
                            Asset = "66001",
                            AssetTagDataSourceName = "AmbTemperatur",
                            AssetTagUnit = "degC",
                            FirstOccurred = DateTime.Now.AddHours(-5),
                            LastOccurred = DateTime.Now,
                            Id = Guid.NewGuid(),
                            LastStateChange = DateTime.Now.AddHours(-1),
                            Message = "Temperature rose over the last 2 hours",
                            Model = "temperature_Watch",
                            ObservationCount = 4,
                            OccurrenceCount = 3,
                            Status = IncidentStatus.Investigating,
                            TagName = "modelAmbTemperature"
                        });
                        retlist.Add(new returnedSet
                        {
                            Asset = "66001",
                            AssetTagDataSourceName = "TemperatureOilEngine",
                            AssetTagUnit = "degC",
                            FirstOccurred = DateTime.Now.AddHours(-4),
                            LastOccurred = DateTime.Now,
                            Id = Guid.NewGuid(),
                            LastStateChange = DateTime.Now.AddHours(-2),
                            Message = "Temperature oscillates over the last 2 hours",
                            Model = "OilTemperature_Watch",
                            //ObservationCount = 6,
                            OccurrenceCount = 4,
                            //TagName = "modelOilTemperature",
                            Status = IncidentStatus.Investigating
                        });
                        retlist.Add(new returnedSet
                        {
                            Asset = "77001",
                            AssetTagDataSourceName = "TemperatureOilEngine",
                            AssetTagUnit = "degC",
                            FirstOccurred = DateTime.Now.AddHours(-4),
                            LastOccurred = DateTime.Now,
                            Id = Guid.NewGuid(),
                            LastStateChange = DateTime.Now.AddHours(-2),
                            Message = "Temperature oscillates over the last 2 hours",
                            Model = "OilTemperature_Watch",
                            //ObservationCount = 6,
                            OccurrenceCount = 4,
                            //TagName = "modelOilTemperature",
                            Status = IncidentStatus.Investigating
                        });
                        retlist.Add(new returnedSet
                        {
                            Asset = "7700x",
                            AssetTagDataSourceName = "TemperatureOilEngine",
                            AssetTagUnit = "degC",
                            FirstOccurred = DateTime.Now.AddHours(-4),
                            LastOccurred = DateTime.Now,
                            Id = Guid.NewGuid(),
                            LastStateChange = DateTime.Now.AddHours(-2),
                            Message = "Temperature oscillates over the last 2 hours",
                            Model = "OilTemperature_Watch",
                            //ObservationCount = 6,
                            OccurrenceCount = 4,
                            //TagName = "modelOilTemperature",
                            Status = IncidentStatus.Investigating
                        });

                        #endregion

                    }
                }
            }
            catch(Exception e)
            {
                _logger.Error(_classname + "failure reading from " + _ssHost, e);
                throw new ApplicationException("failure reading from SS server");
            }

            return retlist;
        }

        #endregion

    }
}
