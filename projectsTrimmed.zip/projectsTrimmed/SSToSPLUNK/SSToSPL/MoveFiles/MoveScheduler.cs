﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.IO;
using System.Timers;
using System.Configuration;
using FileHandling;

[assembly: log4net.Config.XmlConfigurator(Watch = true)]

namespace MoveFiles
{
    class MoveScheduler
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        #region variables

        private Timer mfTimer = null;

        private string appPath;

        private string filepath;
        private string fileext;
        private double fileage;
        private string archivepath;
        private double fileRetention;

        private string splUrl;
        private string splUser;
        private string splPwd;

        private FilesToMove fm;

        #endregion

        #region constructor and events

        public MoveScheduler()
        {
            mfTimer = new Timer();
            double timerInterval = Convert.ToDouble(ConfigurationManager.AppSettings["interval"])*1000*60;
            mfTimer.Interval = timerInterval;
            mfTimer.AutoReset = true;
            mfTimer.Elapsed += new ElapsedEventHandler(mfTimer_Elapsed);
            IntializeObjects();
        }

        private void mfTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            getFiles();
        }

        public void Start()
        {
            fm.ReadFilesSent();
            mfTimer.Enabled = true;
        }

        public void Stop()
        {
            log.Debug("exiting......");
            mfTimer.Enabled = false;
            fm.PersistFilesSent();
        }

        #endregion

        #region methods

        private void IntializeObjects()
        {
            log.DebugFormat("entry at {0}", DateTime.Now.ToString("yyyyMMddHHmmss"));
            // get config settings
            filepath = ConfigurationManager.AppSettings["filePath"];
            fileext = ConfigurationManager.AppSettings["fileExt"];
            fileage = Convert.ToDouble(ConfigurationManager.AppSettings["fileAgeSeconds"]);
            appPath = Path.GetDirectoryName(System.AppDomain.CurrentDomain.BaseDirectory);
            archivepath = ConfigurationManager.AppSettings["archivedPath"];
            fileRetention = Convert.ToDouble(ConfigurationManager.AppSettings["fileRetentionHours"]);

            // get connection setting to SPLUNK end point
            splUrl = ConfigurationManager.AppSettings["SPLurl"];
            splUser = ConfigurationManager.AppSettings["SPLuser"];
            splPwd = ConfigurationManager.AppSettings["SPLpwd"];

            // instantiate file handler
            fm = new FilesToMove(appPath);
        }

        private bool SendFile(FileInfo file)
        {
            log.Debug("Sending ...." + file.DirectoryName + " " + file.Name);
            bool success = false;
            // url
            string posturl = splUrl + file.Name;

            //authentication
            byte[] credentials = Encoding.ASCII.GetBytes(splUser + ":" + splPwd);
 
            //content
            using(HttpClientHandler ch = new HttpClientHandler())
            {
                try
                {
                    ServicePointManager.ServerCertificateValidationCallback = (message, cert, chain, errors) => { return true; };
                    using(HttpClient client = new HttpClient(ch))
                    using(FileStream fs = File.OpenRead(file.FullName))
                    {
                        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(credentials));
                        StreamContent sc = new StreamContent(fs);
                        sc.Headers.ContentType = new MediaTypeHeaderValue("application/x-www-form-urlencoded");
                        // post and dget rersponse
                        HttpResponseMessage response;
                        response = client.PostAsync(posturl, sc).Result;
                        response.EnsureSuccessStatusCode();
                        string retval = response.Content.ReadAsStringAsync().Result;
                        success = true;
                        log.Debug("  http response: " + retval);
                        //HttpContent cnt = response.Content;
                        //i++;
                        //using (StreamWriter sw = new StreamWriter(@"C:\AdvisoriesServices\AdvisoriesTransfer\Logs\sendfiles.txt", true))
                        //{
                        //    sw.WriteLine(i.ToString() + " " + DateTime.Now.ToString("HH:mm:ss.fff") + " " + file.DirectoryName + " " + file.FullName + " " + file.Name);
                        //}
                    }
                }
                catch(Exception e)
                {
                    log.Error("  failed to send " + file.Name + " through " + splUrl + ". Reason: " + e.Message, e);
                }
            }
            return success;
        }

        private void getFiles()
        {
            DirectoryInfo d = new DirectoryInfo(filepath);
            FileInfo[] Files = d.GetFiles("*." + fileext);
            foreach (FileInfo file in Files)
            {
                if (!fm.IsSent(file.Name))
                {
                    TimeSpan diff = DateTime.Now - file.CreationTime;
                    if (diff.TotalSeconds > fileage)
                    {
                        if (SendFile(file))
                        {
                            fm.AddToSentFiles(file.Name);
                        }
                    }
                }
            }
            // move files
            MoveFiles();
            // delete old archived files
            DeleteArchived();
        }

        private void MoveFiles()
        {
            string filename = "";
            try
            {
                DirectoryInfo d = new DirectoryInfo(filepath);
                FileInfo[] Files = d.GetFiles("*." + fileext);
                foreach (FileInfo file in Files)
                {
                    filename = file.Name;
                    if (fm.IsSent(file.Name))
                    {
                        TimeSpan diff = DateTime.Now - file.CreationTime;
                        if (diff.TotalSeconds > 2*fileage)
                        {
                            file.MoveTo(Path.Combine(archivepath, file.Name));
                            fm.RemoveFromSentFiles(file.Name);
                        }
                    }
                }
            }
            catch(Exception e)
            {
                log.Warn("Could not move file " + filename + ". Reason: " + e.Message, e);
            }
        }

        private void DeleteArchived()
        {
            try
            {
                DirectoryInfo d = new DirectoryInfo(archivepath);
                FileInfo[] archivedFiles = d.GetFiles("*." + fileext);
                foreach (FileInfo file in archivedFiles)
                {
                    TimeSpan diff = DateTime.Now - file.CreationTime;
                    if (diff.TotalHours > fileRetention)
                    {
                        file.Delete();
                    }
                }
            }
            catch(Exception e)
            {
                log.Error("failed to delete archived files: "  + e.Message, e);
            }
        }

        #endregion
    }
}
