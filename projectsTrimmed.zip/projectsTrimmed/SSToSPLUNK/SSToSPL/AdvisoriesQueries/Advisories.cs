﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SmartSignal.Com.EPICenter.Service.Contract;

namespace AdvisoriesQueries
{
    public class Advisories
    {

    }
 
    public class returnedSet
    {
        public Guid Id { get; set; }
        public string Asset { get; set; }
        public string AssetTagDataSourceName { get; set; }
        public string AssetTagUnit { get; set; }
        public DateTime FirstOccurred { get; set; }
        public DateTime LastOccurred { get; set; }
        public string Message { get; set; }
        public IncidentStatus Status { get; set; }
        public DateTime LastStateChange { get; set; }
        public string Model { get; set; }
        public string TagName { get; set; }
        public long ObservationCount { get; set; }
        public long OccurrenceCount { get; set; }
    }
}
