﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace AdvisoriesTransfer
{
    public partial class AdvisoriesService : ServiceBase
    {
        private AdvisoriesScheduler advScheduler;
        public AdvisoriesService()
        {
            InitializeComponent();
            advScheduler = new AdvisoriesScheduler();
        }

        protected override void OnStart(string[] args)
        {
            advScheduler.Start();
        }

        protected override void OnStop()
        {
            advScheduler.Stop();
        }

        // for debugging
        public void OnStart_Debug()
        {
            OnStart(null);
        }
        public void OnStop_Debug()
        {
            OnStop();
        }

    }
}
